package com.example.flupperapp.data_classes

data class Main_tasks_data(
    val text: String,
    val taskId: String,
    val description: String
)
