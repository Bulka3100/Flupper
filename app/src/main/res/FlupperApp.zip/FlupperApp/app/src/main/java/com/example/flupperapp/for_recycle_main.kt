package com.example.flupperapp

import com.example.flupperapp.data_classes.Main_tasks_data

object STUBER {
    val mainTasksList: List<Main_tasks_data> = listOf(
        Main_tasks_data("beebbebe", "1", "BEBEBE"),
        Main_tasks_data("beebbebe", "2", "BEBEBE"),
        Main_tasks_data("beebbebe", "3", "BEBEBE")
    )
}